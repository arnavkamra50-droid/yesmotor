document.getElementById("year").textContent=new Date().getFullYear();
const menu=document.querySelector(".menu"), nav=document.querySelector(".nav nav");
menu?.addEventListener("click",()=>{nav.style.display=nav.style.display==="flex"?"none":"flex";nav.style.position="absolute";nav.style.top="68px";nav.style.left="0";nav.style.right="0";nav.style.background="#111";nav.style.padding="24px 7vw";nav.style.flexDirection="column";});
